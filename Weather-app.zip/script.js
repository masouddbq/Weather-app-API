let city = document.querySelector(".box input")
let btn = document.querySelector(".box button")
let weatherImage = document.querySelector(".weather-icon img")
let weatherTemp = document.querySelector(".weather-temp h2")
let weatherDesc = document.querySelector(".weather-desc h3")

btn.addEventListener("click" , () => {
    let cityName = city.value
    let api = `https://api.openweathermap.org/data/2.5/weather?q=${cityName}&appid=2c946df43b9bdf889b1c7e7fec391216&units=metric`
    fetch(api)
    .then(res => res.json())
    .then(data => {
        console.log(data);

        weatherTemp.innerHTML = `${data.main.temp}°C feels like ${data.main.feels_like} `
        weatherImage.src = `https://openweathermap.org/img/wn/${data.weather[0].icon}.png`
        weatherDesc.innerHTML = data.weather[0].description
        
    })
})